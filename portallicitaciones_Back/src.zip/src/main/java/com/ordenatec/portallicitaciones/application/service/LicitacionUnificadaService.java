package com.ordenatec.portallicitaciones.application.service;

import com.ordenatec.portallicitaciones.api.dto.LicitacionUnificadaDto;
import com.ordenatec.portallicitaciones.infra.persistence.entity.LicitacionCatalunyaEntity;
import com.ordenatec.portallicitaciones.infra.persistence.entity.LicitacionNacionalEntity;
import com.ordenatec.portallicitaciones.infra.persistence.repository.LicitacionCatalunyaJpaRepository;
import com.ordenatec.portallicitaciones.infra.persistence.repository.LicitacionNacionalJpaRepository;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Service
public class LicitacionUnificadaService {

    private final LicitacionNacionalJpaRepository nacionalRepo;
    private final LicitacionCatalunyaJpaRepository catalunyaRepo;

    public LicitacionUnificadaService(LicitacionNacionalJpaRepository nacionalRepo,
                                      LicitacionCatalunyaJpaRepository catalunyaRepo) {
        this.nacionalRepo = nacionalRepo;
        this.catalunyaRepo = catalunyaRepo;
    }

    public Page<LicitacionUnificadaDto> listarUnificadas(String source, String q, int page, int size) {

        String src = (source == null || source.isBlank()) ? "mix" : source.trim().toLowerCase();
        String query = (q == null) ? "" : q.trim();

        int safePage = Math.max(0, page);
        int safeSize = Math.min(Math.max(1, size), 500);

        // truco: traemos suficiente para construir la página mezclada (in-memory)
        int need = (safePage + 1) * safeSize;

        Pageable p = PageRequest.of(0, need, Sort.by(Sort.Direction.DESC, "fechaPublicacion"));

        List<LicitacionUnificadaDto> items = new ArrayList<>();

        if (src.equals("nacional") || src.equals("mix")) {
            Page<LicitacionNacionalEntity> nPage = query.isEmpty()
                    ? nacionalRepo.findAll(p)
                    : nacionalRepo.findByExpedienteContainingIgnoreCaseOrObjetoContainingIgnoreCaseOrOrganoContratanteContainingIgnoreCase(
                            query, query, query, p);

            for (LicitacionNacionalEntity n : nPage.getContent()) {
                items.add(mapNacional(n));
            }
        }

        if (src.equals("catalunya") || src.equals("mix")) {
            Pageable pc = PageRequest.of(0, need, Sort.by(Sort.Direction.DESC, "dataPublicacioAnunci"));
            Page<LicitacionCatalunyaEntity> cPage = query.isEmpty()
                    ? catalunyaRepo.findAll(pc)
                    : catalunyaRepo.findByCodiExpedientContainingIgnoreCaseOrDenominacioContainingIgnoreCaseOrNomOrganContainingIgnoreCase(
                            query, query, query, pc);

            for (LicitacionCatalunyaEntity c : cPage.getContent()) {
                items.add(mapCatalunya(c));
            }
        }

        // ordenar por fechaPublicacion (desc)
        items.sort(Comparator.comparing(LicitacionUnificadaDto::fechaPublicacion,
                Comparator.nullsLast(Comparator.naturalOrder())).reversed());

        // paginar sobre la lista ya mezclada
        int from = safePage * safeSize;
        int to = Math.min(from + safeSize, items.size());
        List<LicitacionUnificadaDto> slice = from >= items.size() ? List.of() : items.subList(from, to);

        return new PageImpl<>(slice, PageRequest.of(safePage, safeSize), items.size());
    }

    private LicitacionUnificadaDto mapNacional(LicitacionNacionalEntity n) {
        String dur = null;
        if (n.getDuracion() != null) {
            dur = n.getDuracion().toPlainString();
            if (n.getDuracionUnidad() != null && !n.getDuracionUnidad().isBlank()) {
                dur = dur + " " + n.getDuracionUnidad();
            }
        }

        return new LicitacionUnificadaDto(
                "NACIONAL",
                (n.getId() != null ? n.getId() : n.getUrl()),
                n.getExpediente(),
                n.getObjeto(),
                n.getObjeto(),
                n.getOrganoContratante(),
                n.getDir3Organo(),
                n.getDependencia(),
                n.getTipoContrato(),
                n.getProcedimiento(),
                n.getEstado(),
                n.getCpvPrincipal(),
                n.getCpvs(),
                n.getNuts(),
                n.getUbicacion(),
                n.getImporteSinIva(),
                n.getImporteSinIva(),
                n.getImporteConIva(),
                n.getImporteAdjudicacion(),
                n.getImporteAdjConIva(),
                n.getAdjudicatario(),
                n.getNifAdjudicatario(),
                n.getNumOfertas(),
                n.getFechaPublicacion(),
                n.getFechaLimite(),
                n.getFechaAdjudicacion(),
                dur,
                n.getUrl()
        );
    }

    private LicitacionUnificadaDto mapCatalunya(LicitacionCatalunyaEntity c) {
        return new LicitacionUnificadaDto(
                "CATALUNYA",
                c.getEnllacPublicacio(),
                c.getCodiExpedient(),
                c.getDenominacio(),
                c.getObjecteContracte(),
                c.getNomOrgan(),
                c.getCodiDir3(),
                c.getNomDepartamentEns(),
                c.getTipusContracte(),
                c.getProcediment(),
                c.getFasePublicacio(),
                c.getCodiCpv(),
                c.getCodiCpv(),
                c.getCodiNuts(),
                c.getLlocExecucio(),
                c.getValorEstimatContracte(),
                c.getPressupostLicitacioSenseIva(),
                c.getPressupostLicitacioAmbIva(),
                c.getImportAdjudicacioSenseIva(),
                c.getImportAdjudicacioAmbIva(),
                c.getDenominacioAdjudicatari(),
                c.getIdentificacioAdjudicatari(),
                c.getOfertesRebudes(),
                c.getDataPublicacioAnunci(),
                c.getTerminiPresentacioOfertes(),
                c.getDataAdjudicacioContracte(),
                c.getDuradaContracte(),
                c.getEnllacPublicacio()
        );
    }
}
