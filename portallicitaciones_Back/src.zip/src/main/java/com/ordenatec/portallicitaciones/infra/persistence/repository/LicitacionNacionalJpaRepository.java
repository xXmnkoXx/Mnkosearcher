package com.ordenatec.portallicitaciones.infra.persistence.repository;

import com.ordenatec.portallicitaciones.infra.persistence.entity.LicitacionNacionalEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LicitacionNacionalJpaRepository extends JpaRepository<LicitacionNacionalEntity, Long> {

    Page<LicitacionNacionalEntity> findByExpedienteContainingIgnoreCaseOrObjetoContainingIgnoreCaseOrOrganoContratanteContainingIgnoreCase(
            String expediente, String objeto, String organo, Pageable pageable
    );
}
